﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace tictactoe.Hubs
{
    public class GameHub : Hub
    {
        public async Task MakeMove(string gameId, int cellIndex, string player)
        {
            await Clients.Others.SendAsync("ReceiveMove", gameId, cellIndex, player);
        }
    }
}
