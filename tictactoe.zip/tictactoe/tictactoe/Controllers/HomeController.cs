using Microsoft.AspNetCore.Mvc;

namespace tictactoe.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View(); // Loads Views/Home/Index.cshtml (Menu)
        }

        public IActionResult SinglePlayer()
        {
            return View(); // Loads Views/Home/SinglePlayer.cshtml (AI vs Human)
        }

        public IActionResult MultiPlayer()
        {
            return View(); // Loads Views/Home/MultiPlayer.cshtml (Human vs Human)
        }
    }
}
