﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace tictactoe.Controllers
{
    [Route("api/game")]
    [ApiController]
    public class GameApiController : ControllerBase
    {
        [HttpPost("ai-move")]
        public IActionResult AIMove([FromBody] int[] board)
        {
            int aiMove = GetBestMove(board);
            return Ok(new { move = aiMove });
        }

        private int GetBestMove(int[] board)
        {
            Random rand = new Random();
            var availableMoves = board.Select((val, idx) => val == 0 ? idx : -1).Where(idx => idx != -1).ToList();
            return availableMoves.Count > 0 ? availableMoves[rand.Next(availableMoves.Count)] : -1;
        }
    }
}
