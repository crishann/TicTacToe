﻿using Microsoft.AspNetCore.Mvc;

namespace tictactoe.Controllers
{
    public class GameController : Controller
    {
        public IActionResult Index()
        {
            return View(); // Menu Page (Index.cshtml)
        }

        public IActionResult SinglePlayer()
        {
            return View(); // Single Player Page (SinglePlayer.cshtml)
        }

        public IActionResult MultiPlayer()
        {
            return View(); // Multiplayer Page (MultiPlayer.cshtml)
        }
    }
}
