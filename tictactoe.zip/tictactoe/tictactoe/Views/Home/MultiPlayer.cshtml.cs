using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tictactoe.Views.Home
{
    public class MultiPlayerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
