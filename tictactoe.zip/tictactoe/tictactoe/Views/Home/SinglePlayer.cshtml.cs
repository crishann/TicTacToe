using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tictactoe.Views.Home
{
    public class SinglePlayerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
